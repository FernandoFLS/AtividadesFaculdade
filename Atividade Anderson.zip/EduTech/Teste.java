package exercicio;

public class Teste {

	public static void main(String[] args) {
		
		System.out.println("a) Clientes: ");
		System.out.println();
		//cliente 1 chamado maria
		Cliente cliente1 = new Cliente("Maria Silva", "Maria@gmail.com", 'F', 25);
		cliente1.mostrarDados();
		
		System.out.println();
		
		//cliente 2 chamado mario, pois é, criatividade 0.
		Cliente cliente2 = new Cliente("Mario Silva", "Mario@gmail.com", 'M', 26);
		cliente2.mostrarDados();
		
		System.out.println("\n\n");
		
	}
	
}
