package exercicio;

public class Servico {

}
