package exercicio;

public class TesteCadastro {

	public static void main(String[] args) {
		
		System.out.println("b) Produtos: ");
		System.out.println();
		//banana
		CadastroProdutos produto1 = new CadastroProdutos("Banana", 20, 5);
		produto1.mostrarDados();
		
		System.out.println();
		
		
		//manga
		CadastroProdutos produto2 = new CadastroProdutos("Manga", 1, 7);
		produto2.mostrarDados();
		
		System.out.println();
		
		//abobra :D
		CadastroProdutos produto3 = new CadastroProdutos("Abóbora", 1, 15);
		produto3.mostrarDados();
		
		System.out.println();
		
	}
	
}
