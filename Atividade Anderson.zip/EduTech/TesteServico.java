package exercicio;

public class TesteServico {

}
