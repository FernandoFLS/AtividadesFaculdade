package sistema;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Aluno extends Pessoa {
    private final String numeroMatricula;
    private final LocalDate dataIngresso;
    private final List<Matricula> matriculas;

    public Aluno(String nome, String cpf, String email,
                 String login, String senha,
                 String numeroMatricula, LocalDate dataIngresso) {
        super(nome, cpf, email, login, senha);

        this.numeroMatricula = numeroMatricula;
        this.dataIngresso = dataIngresso;
        this.matriculas = new ArrayList<>();
    }

    public void matricular(Curso curso) {
        boolean jaMatriculado = matriculas.stream()
            .anyMatch(m -> m.getCurso() == curso);

        if (jaMatriculado) {
            throw new IllegalArgumentException(
                "O aluno já está matriculado neste curso."
            );
        }

        Matricula matricula = new Matricula(this, curso);
        matriculas.add(matricula);
        curso.adicionarMatricula(matricula);
    }

    public String getNumeroMatricula() {
        return numeroMatricula;
    }

    public LocalDate getDataIngresso() {
        return dataIngresso;
    }

    public List<Matricula> getMatriculas() {
        return List.copyOf(matriculas);
    }
}