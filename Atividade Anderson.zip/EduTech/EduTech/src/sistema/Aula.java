package sistema;

public class Aula {
    private String titulo;
    private int duracaoMinutos;

    public Aula(String titulo, int duracaoMinutos) {
        if (duracaoMinutos <= 0) {
            throw new IllegalArgumentException(
                "A duração deve ser positiva."
            );
        }

        this.titulo = titulo;
        this.duracaoMinutos = duracaoMinutos;
    }

    public String getTitulo() {
        return titulo;
    }

    public int getDuracaoMinutos() {
        return duracaoMinutos;
    }
}
