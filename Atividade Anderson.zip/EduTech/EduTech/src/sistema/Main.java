package sistema;

import java.time.LocalDate;

public class Main {

	public static void main(String[] args) {
		Instrutor instrutor = new Instrutor(
	            "Ana Silva",
	            "11111111111",
	            "ana@edutech.com",
	            "ana.silva",
	            "senha123",
	            "Especialista em programação Java",
	            8
	        );

	        
	        Aluno aluno = new Aluno(
	            "Jonatan Pereira",
	            "22222222222",
	            "Jonatan@email.com",
	            "jonatan.pereira",
	            "aluno123",
	            "MAT001",
	            LocalDate.now()
	        );

	        
	        Curso curso = new Curso(
	            "Programação Java",
	            60,
	            instrutor
	        );

	        
	        Modulo modulo1 = new Modulo(
	            "Lógica de Programação",
	            curso
	        );

	        Modulo modulo2 = new Modulo(
	            "Programação Orientada a Objetos",
	            curso
	        );

	        
	        modulo1.adicionarAula(
	            new Aula("Introdução à lógica", 30)
	        );

	        modulo1.adicionarAula(
	            new Aula("Estruturas condicionais", 45)
	        );

	        modulo2.adicionarAula(
	            new Aula("Classes e objetos", 50)
	        );

	        
	        instrutor.habilitarModulo(modulo1);
	        instrutor.habilitarModulo(modulo2);

	        
	        aluno.matricular(curso);

	        
	        Matricula matricula = aluno.getMatriculas().get(0);
	        matricula.atualizarProgresso(45.0);

	        
	        aluno.getPerfilAcesso().registrarAcesso();

	        
	        System.out.println("=== SISTEMA EDUTECH ===");
	        System.out.println("Aluno: " + aluno.getNome());
	        System.out.println("Matrícula: "
	            + aluno.getNumeroMatricula());

	        System.out.println("Curso: " + curso.getNome());
	        System.out.println("Instrutor responsável: "
	            + curso.getInstrutorResponsavel().getNome());

	        System.out.println("Quantidade de módulos: "
	            + curso.getModulos().size());

	        System.out.println("Progresso: "
	            + matricula.getProgressoPercentual() + "%");

	        System.out.println("Data da matrícula: "
	            + matricula.getDataMatricula());

	        System.out.println("Último acesso: "
	            + aluno.getPerfilAcesso().getUltimoAcesso());

	        System.out.println("Login válido: "
	            + aluno.getPerfilAcesso().autenticar(
	                "carlos.souza", "aluno123"
	            ));
	    }

	}


