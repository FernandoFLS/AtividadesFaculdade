package sistema;


import java.time.LocalDateTime;

public class PerfilAcesso {
    private String login;
    private String senha;
    private LocalDateTime ultimoAcesso;

    public PerfilAcesso(String login, String senha) {
        this.login = login;
        this.senha = senha;
        this.ultimoAcesso = null;
    }

    public void registrarAcesso() {
        ultimoAcesso = LocalDateTime.now();
    }

    public String getLogin() {
        return login;
    }

    public LocalDateTime getUltimoAcesso() {
        return ultimoAcesso;
    }

    public boolean autenticar(String login, String senha) {
        return this.login.equals(login)
                && this.senha.equals(senha);
    }
}