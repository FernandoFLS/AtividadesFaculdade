package sistema;

import java.util.ArrayList;
import java.util.List;

public class Modulo {
    private String nome;
    private final Curso curso;

    private final List<Aula> aulas;
    private final List<Instrutor> instrutoresHabilitados;

    public Modulo(String nome, Curso curso) {
        this.nome = nome;
        this.curso = curso;
        this.aulas = new ArrayList<>();
        this.instrutoresHabilitados = new ArrayList<>();

        curso.adicionarModulo(this);
    }

    public void adicionarAula(Aula aula) {
        if (!aulas.contains(aula)) {
            aulas.add(aula);
        }
    }

    public void adicionarInstrutorHabilitado(Instrutor instrutor) {
        if (!instrutoresHabilitados.contains(instrutor)) {
            instrutoresHabilitados.add(instrutor);
        }
    }

    public String getNome() {
        return nome;
    }

    public Curso getCurso() {
        return curso;
    }

    public List<Aula> getAulas() {
        return List.copyOf(aulas);
    }

    public List<Instrutor> getInstrutoresHabilitados() {
        return List.copyOf(instrutoresHabilitados);
    }
}
