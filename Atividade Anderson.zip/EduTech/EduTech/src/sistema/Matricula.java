package sistema;

import java.time.LocalDate;

public class Matricula {
    private final Aluno aluno;
    private final Curso curso;
    private final LocalDate dataMatricula;
    private double progressoPercentual;

    public Matricula(Aluno aluno, Curso curso) {
        this.aluno = aluno;
        this.curso = curso;
        this.dataMatricula = LocalDate.now();
        this.progressoPercentual = 0.0;
    }

    public void atualizarProgresso(double progresso) {
        if (progresso < 0 || progresso > 100) {
            throw new IllegalArgumentException(
                "O progresso deve estar entre 0 e 100."
            );
        }

        this.progressoPercentual = progresso;
    }

    public Aluno getAluno() {
        return aluno;
    }

    public Curso getCurso() {
        return curso;
    }

    public LocalDate getDataMatricula() {
        return dataMatricula;
    }

    public double getProgressoPercentual() {
        return progressoPercentual;
    }
}