package sistema;

public abstract class Pessoa {
    private String nome;
    private String cpf;
    private String email;
    private final PerfilAcesso perfilAcesso;

    public Pessoa(String nome, String cpf, String email,
                  String login, String senha) {
        this.nome = nome;
        this.cpf = cpf;
        this.email = email;
        this.perfilAcesso = new PerfilAcesso(login, senha);
    }

    public String getNome() {
        return nome;
    }

    public String getCpf() {
        return cpf;
    }

    public String getEmail() {
        return email;
    }

    public PerfilAcesso getPerfilAcesso() {
        return perfilAcesso;
    }
}