package sistema;

import java.util.ArrayList;
import java.util.List;

public class Curso {
    private String nome;
    private int cargaHoraria;
    private final Instrutor instrutorResponsavel;

    private final List<Modulo> modulos;
    private final List<Matricula> matriculas;

    public Curso(String nome, int cargaHoraria,
                 Instrutor instrutorResponsavel) {
        if (cargaHoraria <= 0) {
            throw new IllegalArgumentException(
                "A carga horária deve ser positiva."
            );
        }

        this.nome = nome;
        this.cargaHoraria = cargaHoraria;
        this.instrutorResponsavel = instrutorResponsavel;
        this.modulos = new ArrayList<>();
        this.matriculas = new ArrayList<>();

        instrutorResponsavel.adicionarCursoCoordenado(this);
    }

    public void adicionarModulo(Modulo modulo) {
        if (modulo.getCurso() != this) {
            throw new IllegalArgumentException(
                "O módulo pertence a outro curso."
            );
        }

        if (!modulos.contains(modulo)) {
            modulos.add(modulo);
        }
    }

    public void adicionarMatricula(Matricula matricula) {
        if (matricula.getCurso() != this) {
            throw new IllegalArgumentException(
                "A matrícula pertence a outro curso."
            );
        }

        if (!matriculas.contains(matricula)) {
            matriculas.add(matricula);
        }
    }

    public String getNome() {
        return nome;
    }

    public int getCargaHoraria() {
        return cargaHoraria;
    }

    public Instrutor getInstrutorResponsavel() {
        return instrutorResponsavel;
    }

    public List<Modulo> getModulos() {
        return List.copyOf(modulos);
    }

    public List<Matricula> getMatriculas() {
        return List.copyOf(matriculas);
    }
}
