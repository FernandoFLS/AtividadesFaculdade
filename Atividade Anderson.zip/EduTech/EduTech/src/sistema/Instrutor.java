package sistema;
import java.util.ArrayList;
import java.util.List;

public class Instrutor extends Pessoa {
    private String biografia;
    private int anosExperiencia;

    private final List<Curso> cursosCoordenados;
    private final List<Modulo> modulosHabilitados;

    public Instrutor(String nome, String cpf, String email,
                     String login, String senha,
                     String biografia, int anosExperiencia) {
        super(nome, cpf, email, login, senha);

        this.biografia = biografia;
        this.anosExperiencia = anosExperiencia;
        this.cursosCoordenados = new ArrayList<>();
        this.modulosHabilitados = new ArrayList<>();
    }

    public void adicionarCursoCoordenado(Curso curso) {
        if (curso.getInstrutorResponsavel() != this) {
            throw new IllegalArgumentException(
                "O instrutor não é o responsável por este curso."
            );
        }

        if (!cursosCoordenados.contains(curso)) {
            cursosCoordenados.add(curso);
        }
    }

    public void habilitarModulo(Modulo modulo) {
        if (!modulosHabilitados.contains(modulo)) {
            modulosHabilitados.add(modulo);
            modulo.adicionarInstrutorHabilitado(this);
        }
    }

    public String getBiografia() {
        return biografia;
    }

    public int getAnosExperiencia() {
        return anosExperiencia;
    }

    public List<Curso> getCursosCoordenados() {
        return List.copyOf(cursosCoordenados);
    }

    public List<Modulo> getModulosHabilitados() {
        return List.copyOf(modulosHabilitados);
    }
}