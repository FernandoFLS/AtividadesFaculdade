package exercicio;

public class Projeto {
	
	public Projeto(String nome, String descricao, String datainicio, String datafinal) {
		this.nome = nome;
		this.descricao = descricao;
		this.datainicio = datainicio;
		this.datafinal = datafinal;
	}
	private String nome;
	private String descricao;
	private String datainicio;
	private String datafinal;
	
	
	//nome
	public String getNome() {
		return nome;
	}
	public void Nome(String nome) {
		this.nome = nome;
	}
	
	//descricao
	public String getDescricao() {
		return descricao;
	}
	public void Descricao(String descricao) {
		this.descricao = descricao;
	}
	
	//inicio
	public String getDataInicio() {
		return datainicio;
	}
	public void DataInicio(String datainicio) {
		this.datainicio = datainicio;
	}
	
	//final
	public String getDataFinal() {
		return datafinal;
	}
	public void DataFinal(String datafinal) {
		this.datafinal = datafinal;
	}
	
	
	//mostrar dados
	public void mostrarDados() {
		System.out.println("Nome: " + this.getNome());
		System.out.println("Descrição: " + this.getDescricao());
		System.out.println("Data de Inicio: " + this.getDataInicio());
		System.out.println("Data de finalização: " + this.getDataFinal());

		
	}
	
	
}
