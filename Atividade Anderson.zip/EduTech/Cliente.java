package exercicio;

public class Cliente {
	
	public Cliente(String nome, String email, char sexo, int idade) {
		this.nome = nome;
		this.email = email;
		this.sexo = sexo;
		this.idade = idade;
	}
	private String nome;
	private String email;
	private char sexo;
	private int idade;
	
	
	//nome
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	//email
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	//sexo
	public char getSexo() {
		return sexo;
	}
	public void setSexo(char sexo) {
		this.sexo = sexo;
	}
	
	//idade
	public int getIdade() {
		return idade;
	}
	public void setIdade(int idade) {
		this.idade = idade;
	}
	
	
	//mostrar dados
	public void mostrarDados() {
		System.out.println("Nome: " + this.getNome());
		System.out.println("E-mail: " + this.getEmail());
		System.out.println("Sexo: " + this.getSexo());
		System.out.println("Idade: " + this.getIdade());

		
	}
	
}
