package exercicio;

public class CadastroProdutos {
	
	public CadastroProdutos(String nome, int qnt, int preco) {
		this.nome = nome;
		this.qnt = qnt;
		this.preco = preco;
	}
	private String nome;
	private int qnt;
	private int preco;
	
	//nome
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	//qnt
	public int getQnt() {
		return qnt;
	}
	public void setQnt(int qnt) {
		this.qnt = qnt;
	}
	
	//preco
	public int getPreco() {
		return preco;
	}
	public void setPreco(int preco) {
		this.preco = preco;
	}
	
	
	//mostrar dados
	public void mostrarDados() {
		System.out.println("Nome: " + this.getNome());
		System.out.println("Quantidade: " + this.getQnt());
		System.out.println("Preço: " + this.getPreco());

		
	}
	
}
