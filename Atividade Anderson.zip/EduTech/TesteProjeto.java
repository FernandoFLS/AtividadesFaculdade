package exercicio;

public class TesteProjeto {

	public static void main(String[] args) {
	
	System.out.println("c) Projetos: ");
	System.out.println();
	//Projeto 1
	Projeto projeto1 = new Projeto("Criar site", "Iremos criar um site bolado", "20/10/2026", "05/11/2026");
	projeto1.mostrarDados();
	
	System.out.println();
	
	//Projeto 2
	Projeto projeto2 = new Projeto("Criar programa", "Iremos criar a steam verde, jogos de graça pra sempre", "29/10/2026", "31/02/2077");
	projeto2.mostrarDados();
		
	System.out.println();
	
	}
}
